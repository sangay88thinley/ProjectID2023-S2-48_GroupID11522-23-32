from kivy.app import App
from kivy.uix.widget import Widget
from kivy.lang import Builder

Builder.load_file('main.kv')

import predictor


class MyGridLayout(Widget):
    def press(self):
        q_pred = predictor.QuadPredictor('sample.wav')
        print(q_pred)
        self.ids.lblOutput1.text = q_pred.output_text

    def show_image(self):
        self.ids.plot_img.opacity = 1


class Auralyze(App):
    def build(self):
        return MyGridLayout()


if __name__ == '__main__':
    app = Auralyze()
    app.run()
